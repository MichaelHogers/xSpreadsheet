shinytest::installDependencies()
library(RXSpreadsheet)

context('Shiny example app basic checks')

test_that("Shiny example app starts", {

  app <- shinytest::ShinyDriver$new('.')

  RXSpreadsheetElement <- app$findElement('.RXSpreadsheet')

  expect_true(typeof(RXSpreadsheetElement) == 'environment')

})
