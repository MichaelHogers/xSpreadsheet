library(testthat)
library(RXSpreadsheet)

test_check("RXSpreadsheet")
